export * from './taskRestController.service';
import { TaskRestControllerService } from './taskRestController.service';
export const APIS = [TaskRestControllerService];
